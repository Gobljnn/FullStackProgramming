public class newCar extends Car{
    String colour = "" ;

    public void getColour(String colour) {
        this.colour = colour ;
    }

    public newCar(double cost, String colour){
        this.cost = cost;
        this.colour = colour;
    }

    public void display2() {
       System.out.println("The colour of the new car is " + this.colour);
    }
}
