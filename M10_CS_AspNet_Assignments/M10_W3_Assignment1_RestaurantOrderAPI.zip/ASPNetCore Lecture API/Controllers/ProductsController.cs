﻿using ASPNetCore_Lecture_API.Data;
using ASPNetCore_Lecture_API.Models;
using ASPNetCore_Lecture_API.ModelsDTO;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ASPNetCore_Lecture_API.Controllers {
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase {
        private readonly RestDbContext _context;

        public ProductsController(RestDbContext context) {
            _context = context;
        }
        // GET: api/<ProductsController>
        [HttpGet]
        public ActionResult Get() {
            return Ok(_context.Products);

        }

        // GET api/<ProductsController>/5
        [HttpGet("{id}")]
        public ActionResult Get(int id) {
            var products = _context.Products.FirstOrDefault(p => p.Id == id);

            if (products != null) {
                return Ok(products);
            }
            return NotFound();
        }
        // POST api/<ProductsController>
        [HttpPost]
        public ActionResult Post(ProductCreateDto value) {

            Product productToAdd = new Product {
                Name = value.Name,
                Price = value.Price,
            };
            _context.Products.Add(productToAdd);
            _context.SaveChanges();


            return Ok();
        }
         
        // PUT api/<ProductsController>/5  Put is used to update.
        [HttpPut("{id}")] 
        public ActionResult Put(int id, ProductCreateDto value) {

            var productFromDb = _context.Products.FirstOrDefault(p => p.Id == id);

            if (productFromDb != null) {
                productFromDb.Name = value.Name;
                productFromDb.Price = value.Price;
                _context.SaveChanges();
            }

            else {

                return NotFound(); //404
            }

            return Ok();
        }

        // DELETE api/<ProductsController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id) {
            var productFromDb = _context.Products.FirstOrDefault(p => p.Id == id);

            if (productFromDb != null) {
                _context.Products.Remove(productFromDb);
                _context.SaveChanges();
               
            }

            else {

                return NotFound(); //404
            }

            return Ok();
        }
    }
}
