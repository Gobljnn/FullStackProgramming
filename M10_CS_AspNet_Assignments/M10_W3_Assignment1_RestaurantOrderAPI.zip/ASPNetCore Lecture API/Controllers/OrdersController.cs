﻿using ASPNetCore_Lecture_API.Data;
using ASPNetCore_Lecture_API.Models;
using ASPNetCore_Lecture_API.ModelsDTO;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ASPNetCore_Lecture_API.Controllers {
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase {
        private readonly RestDbContext _context;

        public OrdersController(RestDbContext context) {
            _context = context;
        }
        // GET: api/<OrdersController>
        [HttpGet]
        public ActionResult Get() {

            var orders = _context.Orders
                .Select(o => new OrderDto { Id = o.Id, Name = o.Name, Date = o.Date })
                .ToList();

            var orderProducts = _context.OrderProducts.ToList();

            foreach (var order in orders) {
                var productstoAdd = new List<ProductDto>();
                foreach (var op in orderProducts) {
                    if (op.OrderId == order.Id) {
                        ProductDto p = _context.Products
                            .Where(p => p.Id == op.ProductId)
                            .Select(p => new ProductDto {
                                Id = p.Id,
                                Name = p.Name,
                                Price = p.Price
                            })
                            .First();
                        productstoAdd.Add(p);
                    }
                }
                order.Products = productstoAdd;
            }
            return Ok(orders);
        }

        // GET api/<OrdersController>/5
        [HttpGet("{id}")]
        public ActionResult Get(int id) {

            OrderDto order = _context.Orders
                .Where(o => o.Id == id)
                .Select(o => new OrderDto { Id = o.Id, Name = o.Name, Date = o.Date })
                .FirstOrDefault();

            //if (order == null) return NotFound();

            if (order != null) {
                var orderProducts = _context.OrderProducts.ToList();

                //foreach (var order in orders) { 
                var productstoAdd = new List<ProductDto>();
                foreach (var op in orderProducts) {
                    if (op.OrderId == order.Id) {
                        ProductDto p = _context.Products
                            .Where(p => p.Id == op.ProductId)
                            .Select(p => new ProductDto {
                                Id= p.Id,
                                Name = p.Name,
                                Price = p.Price
                            })
                            .First();
                        productstoAdd.Add(p);
                    }
                }
                order.Products = productstoAdd;
            }

            else {
                return NotFound();
            }
            //}
            return Ok(order);
        }

        // POST api/<OrdersController>
        [HttpPost]
        public ActionResult Post(OrderProductsCreateDto value) {

        /* Take the ORderProductsCreate model and input a Name and Date
            It will also list out the productscreateDto Model
         */

            Order orderToAdd = new Order {
                Name = value.Name,
                Date = value.Date,
            };

            _context.Orders.Add(orderToAdd);
            _context.SaveChanges();

            foreach (var item in value.ProductIds){
                var ohp = new OrderProducts{
                    OrderId = orderToAdd.Id,
                    ProductId = item
                };
                _context.OrderProducts.Add(ohp);
            }

            _context.SaveChanges();

        /* Create an object based on the Order model ID is automatically created so only
         * name & date has to be done
         */


        /* If possible - Find a way to populate the field already based on how much the customer wants to order*/


            return Ok();
        }

        // PUT api/<OrdersController>/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, OrderProductsCreateDto value) {

            /* Take the id from input - Take the OrderProductsCreate model 
             */

            /* Find order number from OrderTable */

            var orderFromDb = _context.Orders
                .FirstOrDefault(p => p.Id == id);

            if (orderFromDb != null) { 
                orderFromDb.Name = value.Name;
                orderFromDb.Date = value.Date;

                var prodRange = _context.OrderProducts
                    .Where(p => p.OrderId == id).ToList();

                foreach (var item in value.ProductIds) {
                    var ohp = new OrderProducts {
                        OrderId = id,
                        ProductId = item
                    };
                    _context.OrderProducts.Add(ohp);
                }

                _context.SaveChanges();

            }

            else {
                return NotFound();
            }


            return Ok();
        }

        // DELETE api/<OrdersController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id) {

            var delOrderFromDb = _context.Orders
                .FirstOrDefault(p => p.Id == id);

            
            if (delOrderFromDb != null) {

                _context.Orders.Remove(delOrderFromDb);
                var prodRange = _context.OrderProducts
                    .Where(p => p.OrderId == id)
                    .ToList();

                _context.OrderProducts.RemoveRange(prodRange);

                _context.SaveChanges();

            }

            else {

                return NotFound(); //404
            }

            return Ok();
        }
    }
}
