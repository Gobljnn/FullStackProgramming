﻿namespace ASPNetCore_Lecture_API.ModelsDTO {
    public class ProductCreateDto {
        public string Name { get; set; }
        public double Price { get; set; }


    }
}
