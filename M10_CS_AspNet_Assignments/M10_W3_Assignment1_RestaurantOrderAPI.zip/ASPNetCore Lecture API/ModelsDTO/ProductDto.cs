﻿using System.Collections.Generic;

namespace ASPNetCore_Lecture_API.ModelsDTO {
    public class ProductDto {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        //public List<OrderDto> Orders { get; set; }
    }
}
