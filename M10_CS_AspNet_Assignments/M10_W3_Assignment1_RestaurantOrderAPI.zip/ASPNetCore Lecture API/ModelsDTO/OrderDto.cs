﻿using ASPNetCore_Lecture_API.Models;
using System;
using System.Collections.Generic;

namespace ASPNetCore_Lecture_API.ModelsDTO {
    public class OrderDto {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }

        public List<ProductDto> Products { get; set; }
    }
}
