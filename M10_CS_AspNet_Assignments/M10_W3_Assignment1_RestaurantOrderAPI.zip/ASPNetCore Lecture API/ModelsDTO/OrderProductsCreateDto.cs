﻿using System;
using System.Collections.Generic;

namespace ASPNetCore_Lecture_API.ModelsDTO {
    public class OrderProductsCreateDto {
        public string Name { get; set; }
        public DateTime Date { get; set; }
        //public double Price { get; set; }

        public List<int> ProductIds { get; set; }

        //public ProductInOrdersDto ProductInOrders { get; set; }


        //public List<ProductCreateDto> Products { get; set; }
         
    }
}
