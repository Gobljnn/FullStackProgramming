﻿namespace ASPNetCore_Lecture_API.ModelsDTO {
    public class ProductInOrdersDto {
        public string PName { get; set; }
        public double PPrice { get; set; }
    }
}
