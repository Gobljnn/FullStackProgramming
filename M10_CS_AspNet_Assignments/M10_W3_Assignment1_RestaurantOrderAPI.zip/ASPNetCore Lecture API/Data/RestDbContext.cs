﻿using ASPNetCore_Lecture_API.Models;
using ASPNetCore_Lecture_API.ModelsDTO;
using Microsoft.EntityFrameworkCore;
using System;

namespace ASPNetCore_Lecture_API.Data {
    public class RestDbContext : DbContext {

        public RestDbContext(DbContextOptions<RestDbContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderProducts> OrderProducts { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder) { 
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Product>().HasData(
                    new Product { Id = 1, Name = "Spaghetti", Price = 14.99 },
                    new Product { Id = 2, Name = "Burger", Price = 4.55 },
                    new Product { Id = 3, Name = "Coca-Cola", Price = 2.99 },
                    new Product { Id = 4, Name = "Cake", Price = 6.42},
                    new Product { Id = 5, Name = "Fries", Price = 2.75 }

                );

            modelBuilder.Entity<Order>().HasData(
                new Order { Id = 1, Name = "Bob's Order", Date = DateTime.Now },
                new Order { Id = 2, Name = "Mike's Order", Date = DateTime.Now},
                new Order { Id = 3, Name = "Ruslan's Order", Date = DateTime.Now},
                new Order { Id = 4, Name = "Dammy's Order", Date = DateTime.Now}

                );

            modelBuilder.Entity<OrderProducts>().HasData(
                new OrderProducts { Id = 1, OrderId = 2, ProductId = 1 },
                new OrderProducts { Id = 2, OrderId = 2, ProductId = 3},
                new OrderProducts { Id = 3, OrderId = 1, ProductId = 4 },
                new OrderProducts { Id = 4, OrderId = 1, ProductId = 3 },
                new OrderProducts { Id = 5, OrderId = 1, ProductId = 5 },
                new OrderProducts { Id = 6, OrderId = 4, ProductId = 3 },
                new OrderProducts { Id = 7, OrderId = 4, ProductId = 5 },
                new OrderProducts { Id = 8, OrderId = 3, ProductId = 2 },
                new OrderProducts { Id = 9, OrderId = 3, ProductId = 3 }
                );

        }




    }
}
